import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class pong extends PApplet {

int WIDTH = 720;
int HEIGHT = WIDTH*9/16;
boolean upPressed = false;
boolean downPressed = false;



//Paddle(double x, double y, double speed, double size)
Paddle p1 = new Paddle(0.03f,0.5f,0.03f, 0.2f);
Ball b = new Ball(0.5f,0.5f,2,0.05f);
Paddle p2 = new Paddle(0.95f, 0.5f, 0.03f, 0.2f);

int p1score = 0;
int p2score = 0;

public void tick(){
  if(upPressed){
   p1.movePaddle(-1); 
  }
  if(downPressed){
   p1.movePaddle(1); 
  }
  
  if(b.getY()+0.02f<p2.getY()){
   p2.movePaddle(-0.7f); 
  }
  if(b.getY()-0.02f>p2.getY()){
   p2.movePaddle(0.7f); 
  }
  b.tick();
  if(b.colliding(p1) != -1){
    b.setAngleBounce((b.colliding(p1)-0.5f)/100);
  }
  if(b.colliding(p2) != -1){
    b.setAngleBounce((b.colliding(p2)-0.5f)/100);
  }
  
  if(b.getX()+b.getSize()>=1){
   p1score++;
   b.setSpeed(b.getSpeed()+0.5f);
   b.setX(0.5f);
   b.setY(0.5f);
   delay(1000);
  }
  if(b.getX()<=0){
   b.setSpeed(b.getSpeed()-0.5f);
   p2score++; 
   b.setX(0.5f);
   b.setY(0.5f);
   delay(1000);
  }
  
}

public void render(){
  background(0);
  p1.render();  
  p2.render();
  b.render();
  textSize(height/10);
  text(p1score, 0.02f*width,0.1f*height);
  text(p2score, 0.95f*width,0.1f*height);
}
public void settings() {
  size((int)WIDTH, (int)HEIGHT);
  
}
public void setup(){
  surface.setResizable(true);
  background(0);
}


public void draw(){
  noStroke();
  tick();
  render();
  fill(255);
}

public void keyPressed(){
  if (key == CODED) {
    if (keyCode == UP) {
      upPressed = true;
    }
    if (keyCode == DOWN) {
      downPressed = true;
    }
  }
}

public void keyReleased(){
  if (key == CODED) {
    if (keyCode == UP) {
      upPressed = false;
    }
    if (keyCode == DOWN) {
      downPressed = false;
    }
  }
}
class Ball{
 double x;
 double y;
 double dx;
 double dy;
 double speed;
 double size;
 
 Ball(double x, double y, double speed, double size){
   this.x = x;
   this.y = y;
   this.dx = random(-0.01f,0.01f);
   this.dy = random(-0.01f,0.01f);
   this.speed = speed;
   this.size = size;
 }
 
 public double getX(){
   return x; 
 }
 public double getY(){
   return y; 
 }
 public void setX(double x){
  this.x = x; 
 }
 public void setY(double y){
  this.y = y; 
 }
 
 
 public double getSpeed(){
   return speed;
 }
 public void setSpeed(double speed){
   this.speed = speed;
 }
 public double getSize(){
   return this.size;
 }
 public void setSize(double size){
   this.size = size; 
 }
 
 public void setAngleBounce(double angle){
   this.dx = -this.dx;
   this.dy = angle+random(-0.005f,0.005f);
 }
 public void tick(){
  this.x+=this.dx*speed;
  this.y+=this.dy*speed;
  if(this.y<=0.001f || this.y+this.size>=0.999f){
    
   this.dy = -this.dy; 
  }
  if(this.x<=0.001f || this.x+this.size>=0.999f){
   this.dx = -this.dx; 
  } 
 }
 
 
 
 public double colliding(Paddle p){
   double ret = -1;
   if(
   this.x < p.x + p.getWidth() &&
   this.x + this.size > p.x &&
   this.y < p.y + p.getHeight() &&
   this.y + this.size > p.y){
    ret = (this.y-p.y)/p.getHeight(); 
   }
   return ret;
 }
 
 
 public void render(){
  fill(255);
  rect((float)x*width,(float)y*height,(float)size*height, (float)size*height); 
 }
  
}



class Paddle{
 double x;
 double y;
 double speed;
 double size;
 
 Paddle(double x, double y, double speed, double size){
   this.x = x;
   this.y = y;
   this.speed = speed;
   this.size = size;
 }
 
 public double getX(){
   return x; 
 }
 public double getY(){
   return y; 
 }
 public double getSpeed(){
   return speed;
 }
 public void setSpeed(double speed){
   this.speed = speed;
 }
 public double getWidth(){
   return this.size/8;
 }
 public double getHeight(){
  return this.size; 
 }
 public void setSize(double size){
   this.size = size; 
 }
 
 public void movePaddle(double dy){
   if(this.y+dy*speed>0 &&this.y+this.size+dy*speed<1){
     this.y+=dy*speed;
   }
 }
 
 
 public void render(){
  fill(255);
  rect((float)x*width,(float)y*height,(float)(size/8)*width, (float)size*height); 
 }
  
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "pong" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
